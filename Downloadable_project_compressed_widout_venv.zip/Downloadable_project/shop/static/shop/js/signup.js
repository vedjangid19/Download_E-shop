console.log("signup form ")
var token = null
var loading = null
window.onload = function(){
    loading = document.getElementById('loading')
}

function validate(event) {
    var error = document.getElementById('message')
    var message = null

    var values = event.target.elements;
    var form = event.target
    
    var name = values.name.value
    var email = values.email.value
    token = values.csrfmiddlewaretoken.value

    message = validateForm(form)

    if (message) {
        error.innerHTML = message
        error.hidden = false
    } else {
        error.innerHTML = ""
        error.hidden = true

        sendEmail(email, name, token)
    }

    event.stopPropagation();
    return false
}


function validateForm(form){

    message=null;

    var values = form.elements
    var name = values.name.value
    // var phone = values.phone.value
    var email = values.email.value
    var password = values.password.value
    var repassword = values.repassword.value
    token = values.csrfmiddlewaretoken.value

    if (!name.trim()) {
        message = "Name is required!"
    }
    else if (!email.trim()) {
        message = "Email is required!"
    }
    else if (!password.trim()) {
        message = "Password is required!"
    }
    else if (!repassword.trim()) {
        message = "Password is required!"
    }
    else if (password.trim() != repassword.trim()) {
        message = "Password not matched!"
    }

    return message
}

function sendEmail(email, name, token) {
    loading.hidden = false
    $.ajax({
        type: "POST",
        url: "/send-otp/",
        data: { name: name, email: email, 'csrfmiddlewaretoken': token }

    })
        .done(function (msg) {
            // alert("data saved " + msg)
            loading.hidden = true
            showOtpInput()
        }).fail(function (err){
            loading.hidden = true
            alert("can't send Email ")
        })
}

function showOtpInput(){
    var verificationInput = document.getElementById('verificationInput')
    var verifyButton = document.getElementById('verifyButton')
    var submit = document.getElementById('submitButton')
    verificationInput.hidden = false
    verifyButton.hidden = false
    submit.hidden = true
}

function verifyCode(){
    var codeInput = document.getElementById('code')
    var code = codeInput.value
    loading.hidden = false
    $.ajax({
        type: "POST",
        url: "/verify/",
        data: { 'code': code, 'csrfmiddlewaretoken': token }

    })
        .done(function (msg) {
            loading.hidden = true
            submitForm()
            
        }).fail(function (err){
            loading.hidden = true
            alert("verification code invalid")
        })
}

function submitForm(){
    var form = document.getElementById('form')
    var message = validateForm(form)
    try{
        if(message){
            console.log("if part of submit form")
        }
        else{
            form.submit()
        }

    }
    catch(err){

    }

}