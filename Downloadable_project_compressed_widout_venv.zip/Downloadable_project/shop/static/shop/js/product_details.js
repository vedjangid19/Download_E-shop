function init(){

}

function changeImage(event){
    var mainImage = document.getElementById('mainImage')
    // console.log(mainImage.src)
    mainImage.src = event.target.src
}


window.onload = init()