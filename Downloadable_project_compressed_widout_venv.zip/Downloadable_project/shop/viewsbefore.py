from django.shortcuts import render, HttpResponse, redirect
from shop.models.products import Product, ProductImages
from shop.models import User
from shop.utils.email_sender import sendEmail
from django.contrib.auth.hashers import make_password, check_password
import random
import math


# Create your views here.


# def index(request):
#     # sendEmail("name", "vedprakashjangid.jpr@gmail.com", 'subject', "<h1>this is email from python index</h1>")
#
#     products = Product.objects.filter(active=True)
#     data = {
#         'products': products
#     }
#     return render(request, 'index.html', data)


# def login(request):
#     if request.method == 'GET':
#         return render(request, 'login.html')
#
#     email = request.POST.get('email')
#     password = request.POST.get('password')
#     # print(email, password)
#
#     try:
#         user = User.objects.get(email=email)
#         flag = check_password(password=password, encoded=user.password)
#
#         if flag:
#             return redirect('index')
#         else:
#             return render(request, 'login.html', {'error': 'Email or Password invalid'})
#     except:
#         return render(request, 'login.html', {'error': 'Email or Password invalid'})



# def serveSingnUpForm(request):
#     if request.method == 'POST':
#         try:
#             name = request.POST.get('name')
#             phone = request.POST.get('phone')
#             email = request.POST.get('email')
#             password = request.POST.get('password')
#             hashed_password = make_password(password=password)
#             user = User(name=name, phone=phone, email=email, password=hashed_password)
#             user.save()
#             return render(request, 'login.html')
#         except:
#             return render(request, 'signup.html', {'error': 'User already Registered..!'})
#
#     return render(request, 'signup.html')


# def sendOtp(request):
#     name = request.POST.get('name')
#     email = request.POST.get('email')
#     # print(name, email)
#     otp = math.floor(random.random() * 1000000)
#     html = f'''
#                 Hello {name}
#                 <br>
#                 your verification code is : <b>{otp}</b>
#             '''
#     if name and email:
#         response = sendEmail(name=name, email=email, subject='Verify Code', htmlContent=html)
#         print("responce is send email", response)
#
#         try:
#             if response.status_code == 200:
#                 request.session['verification-code'] = otp
#                 return HttpResponse("{'message': 'success'}", status=200)
#             else:
#                 return HttpResponse(status=400)
#         except:
#             return HttpResponse(status=400)


# def productDetail(request, product_id):
#     product = Product.objects.get(id=product_id)
#     images = ProductImages.objects.filter(product=product_id)
#     return render(request, 'productdetail.html', {'product': product, 'images': images})

#
# def verify(request):
#     code = request.POST.get('code')
#     otp = request.session.get('verification-code')
#
#     if str(code) == str(otp):
#
#         return HttpResponse("{'verify code': 'success'}", status=200)
#     else:
#         return HttpResponse("{'verify code': 'failed'}", status=400)
