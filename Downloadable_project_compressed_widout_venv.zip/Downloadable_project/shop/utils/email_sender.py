import requests
from downloadable_project.settings import EMAIL_SERVICE_ENDPOINT, EMAIL_API_KEY, EMAIL_SENDER_NAME, EMAIL_SENDER_EMAIL


def sendEmail(name, email, subject, htmlContent):
    return requests.post(
        "https://api.mailgun.net/v3/sandbox6bf38b7ba0a34b029d508e45797ca840.mailgun.org/messages",
        auth=("api", "a1a2a3d29595197ef9abe533e964a172-0f472795-60882ffd"),
        data={"from": "DownloadableProduct <mailgun@sandbox6bf38b7ba0a34b029d508e45797ca840.mailgun.org>",
              "to": [email],
              "subject": subject,
              "html": htmlContent})