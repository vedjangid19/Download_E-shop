from django.shortcuts import render, HttpResponse, redirect

def cantAccessAfterLogin(get_response):

    def middleware(request, product_id=None):
        user = request.session.get('user')

        if user:
            return redirect('index')
        else:
            response = get_response(request)
            return response

    return middleware