from shop.utils.email_sender import sendEmail
from django.shortcuts import render, HttpResponse, redirect
import random
import math


def sendOtp(request):
    name = request.POST.get('name')
    email = request.POST.get('email')
    # print(name, email)
    otp = math.floor(random.random() * 1000000)
    html = f'''
                Hello {name}
                <br>
                your verification code is : <b>{otp}</b>
            '''
    if name and email:
        response = sendEmail(name=name, email=email, subject='Verify Code', htmlContent=html)
        print("responce is send email", response)

        try:
            if response.status_code == 200:
                request.session['verification-code'] = otp
                return HttpResponse("{'message': 'success'}", status=200)
            else:
                return HttpResponse(status=400)
        except:
            return HttpResponse(status=400)


def verify(request):
    code = request.POST.get('code')
    otp = request.session.get('verification-code')

    if str(code) == str(otp):

        return HttpResponse("{'verify code': 'success'}", status=200)
    else:
        return HttpResponse("{'verify code': 'failed'}", status=400)
