from django.views import View
from django.contrib.auth.hashers import make_password, check_password
from shop.models import User
from django.shortcuts import render, HttpResponse, redirect


class SignupView(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        if request.method == 'POST':
            try:
                name = request.POST.get('name')
                phone = request.POST.get('phone')
                email = request.POST.get('email')
                password = request.POST.get('password')
                hashed_password = make_password(password=password)
                user = User(name=name, phone=phone, email=email, password=hashed_password)
                user.save()
                return render(request, 'login.html')
            except:
                return render(request, 'signup.html', {'error': 'User already Registered..!'})

