from django.shortcuts import render, HttpResponse, redirect
from shop.models.products import Product, ProductImages


def index(request):
    # sendEmail("name", "vedprakashjangid.jpr@gmail.com", 'subject', "<h1>this is email from python index</h1>")

    products = Product.objects.filter(active=True)
    data = {
        'products': products
    }
    return render(request, 'index.html', data)


def logout(request):
    request.session.clear()
    return redirect('index')
