from django.shortcuts import render, HttpResponse, redirect
from shop.models.products import Product, ProductImages
from shop.models import User, Payment
from django.db.models import Q


def my_orders(request):
   user_id = request.session.get('user').get('id')
   user = User.objects.get(id=user_id)
   # print(user)
   payments = Payment.objects.filter(~Q(status='Failed'), user=user)
   # print(payments)
   return render(request, 'order.html', {'orders': payments})
