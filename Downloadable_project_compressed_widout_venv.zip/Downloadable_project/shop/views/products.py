from shop.models.products import Product, ProductImages
from django.shortcuts import render, HttpResponse, redirect
from shop.models.products import Product, ProductImages
from shop.models import User, Payment
from django.db.models import Q


def productDetail(request, product_id):
    product = Product.objects.get(id=product_id)
    images = ProductImages.objects.filter(product=product_id)

    can_download = False
    try:
        session_user = request.session.get('user')
        if session_user:
            user_id = session_user.get('id')
            user = User(id=user_id)
            payment = Payment.objects.filter(~Q(status='Failed'), user=user, product=product)
            print(payment)
            if len(payment) != 0:
                can_download = True
    except:
        pass

    return render(request, 'productdetail.html', {'product': product, 'images': images, 'can_download': can_download})
