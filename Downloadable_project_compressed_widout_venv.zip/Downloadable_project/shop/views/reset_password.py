

from django.shortcuts import render, HttpResponse, redirect
from django.views import View
from shop.models import User
from django.contrib.auth.hashers import make_password, check_password
from shop.utils.email_sender import sendEmail
import math
import random


class resetPasswordView(View):

    def get(self, request):
        return render(request, 'reset_password.html', {'step1': True})

    def post(self, request):
        email = request.session['reset-password-email']
        password = request.POST.get('newpassword')
        repassword = request.POST.get('renewpassword')

        error = None
        if len(password) < 6:
            error = "Password should be 6 char long and more"
        elif len(repassword) < 6:
            error = "Password should be 6 char long and more"
        elif password != repassword:
            error = "Password not matched"

        if error:
            return render(request, 'reset_password.html', {'step3': True, 'error': error})
        else:
            user = User.objects.get(email=email)
            user.password = make_password(password)
            user.save()
            request.session.clear()
            sendEmailAfterChangePassword(user)
            return render(request, 'login.html', {'message': 'Password Changed..!'})


def sendEmailAfterChangePassword(user):
    html = f'''
            <p>Your Password change successfully..!</p>'''
    sendEmail(user.name, user.email, 'Change Password', html)


def VerifyResetPasswordCode(request):
    code = request.POST.get('code')
    session_code = request.session.get('reset-password-verification-code')
    # print("VerifyResetPasswordCode :::",code, session_code)
    if str(code) == str(session_code):
        return render(request, 'reset_password.html', {'step3': True})
    else:
        return render(request, 'reset_password.html', {'step2': True})

class ResetPasswordVerification(View):

    def post(self, request):
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
            otp = math.floor(random.random() * 1000000)
            html = f'''
            hello {user.name}
            <p>Your Password Reset Verification code {otp}</p>
            '''
            sendEmail("user", email, 'Password reset verification code', html)

            request.session['reset-password-verification-code'] = otp
            request.session['reset-password-email'] = email
            return render(request, 'reset_password.html', {'step2': True})
        except:
            return redirect('resetPasswordView')
