
from django.contrib import admin
from django.urls import path
from shop.views import index
from shop.views.download import downloadFree, downloadPaidProduct
from shop.views import LoginView, SignupView
from shop.views.email_verification import sendOtp, verify
from shop.views.products import productDetail
from shop.views.order import my_orders
from shop.views.payment import createPayment, verifyPayment
from shop.middleware.login_required_middleware import loginRequired
from shop.middleware.can_not_access_after_login import cantAccessAfterLogin
from shop.views.reset_password import resetPasswordView, ResetPasswordVerification, VerifyResetPasswordCode

urlpatterns = [
    path('', index.index, name='index'),
    path('logout/', index.logout, name='logout'),
    path('order/', loginRequired(my_orders), name='orders'),
    path('login/', cantAccessAfterLogin(LoginView.as_view()), name='login'),
    path('send-otp/', cantAccessAfterLogin(sendOtp), name='sendOtp'),
    path('verify/', cantAccessAfterLogin(verify), name='verify'),
    path('signup/', cantAccessAfterLogin(SignupView.as_view()), name='singnUpForm'),
    path('product/<int:product_id>', productDetail, name='productDetail'),

    path('download-free/<int:product_id>', loginRequired(downloadFree), name='downloadFree'),

    path('download/paidproduct/<int:product_id>', loginRequired(downloadPaidProduct), name='downloadPaidProduct'),

    path('create-payment/<int:product_id>', loginRequired(createPayment), name='createPayment'),

    path('complete-payment', verifyPayment, name='verifyPayment'),

    path('reset-password', resetPasswordView.as_view(), name='resetPasswordView'),#step-1
    path('reset-password-verification', ResetPasswordVerification.as_view(), name='ResetPasswordVerification'),
    path('verify-reset-password-code', VerifyResetPasswordCode, name='VerifyResetPasswordCode'),
]
